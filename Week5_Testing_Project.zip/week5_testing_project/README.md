# Week 5 – Testing, Debugging and Optimization

A small **Task Manager** app (Flask REST API + JavaScript UI helpers) used to practise
unit testing, integration testing, debugging and performance optimization.

## Project structure
```
backend/      Flask API (app.py), in-memory store (store.py), validators (validators.py)
frontend/     UI helper functions (utils.js)
tests/
  backend/    test_validators.py, test_store.py  (unit)   test_api_integration.py (integration)
  frontend/   utils.test.js (unit + rendering tests)
benchmarks/   profile_duplicates.py  (cProfile + timeit)
logs/         error_log_before_fix.txt, test_results_after_fix.txt, profiling_report.txt
docs/         debugging_process.md  (bugs found, root causes, lessons learned)
```

## Setup
```bash
pip install -r requirements.txt     # Flask + pytest
# Node.js 18+ is required for the front-end tests (uses the built-in node:test runner, no npm install needed)
```

## How to run the tests
```bash
./run_all_tests.sh                  # everything
python -m pytest -v                 # backend only  (or: python -m unittest discover -s tests/backend -t . -v)
node --test tests/frontend/utils.test.js   # frontend only  (or: npm test)
python benchmarks/profile_duplicates.py    # performance benchmark
```

## Testing strategy
| Level | What is tested | Files |
|---|---|---|
| Unit (back-end) | `validate_title`, `priority_score`, `TaskStore` methods in isolation | `test_validators.py`, `test_store.py` |
| Integration (back-end) | HTTP routes -> validators -> store working together; full create / list / get / delete lifecycle; error codes 400 / 404 | `test_api_integration.py` |
| Unit (front-end) | `escapeHtml`, `filterTasks`, `formatDueDays`, `renderTaskList` | `utils.test.js` |

Techniques used: happy path, boundary values (100 vs 101 characters, importance 1-5, due today),
negative tests (blank, `None`, wrong type, invalid JSON, missing IDs), regression tests for each bug,
and a security test (XSS escaping). `setUp` creates a fresh store per test so tests stay independent.

**Result:** 35 tests (27 back-end + 8 front-end). First run: 15 failed (5 real bugs). After fixes: 35/35 pass.

## Debugging summary
Tests were written first and run against the initial code. Failures were captured in
`logs/error_log_before_fix.txt`, traced to root causes, fixed, and re-run
(`logs/test_results_after_fix.txt`). Full details: `docs/debugging_process.md`.

| # | Bug | Symptom | Fix |
|---|---|---|---|
| 1 | `validate_title` did not trim / type-check | blank titles accepted; `TypeError` on numbers | strip + `isinstance` check |
| 2 | `priority_score` divided by days | `ZeroDivisionError` when due today; negative score if overdue; no range check | `max(days, 0.5)` + importance validation |
| 3 | `TaskStore.delete` always returned `True` | API returned 204 for non-existent task | return whether item existed; API returns 404 |
| 4 | `filterTasks` was case-sensitive | searching "milk" did not find "Buy Milk" | lower-case + trim query |
| 5 | `formatDueDays` printed `"null days"` | poor UI text | human-readable messages |

## Optimizations implemented
`find_duplicate_titles` was O(n^2) (nested loop + list lookup). Replaced with a single pass using
`collections.Counter` (O(n)). Measured with `timeit` and `cProfile` (`logs/profiling_report.txt`):

| Tasks | Before (s) | After (s) | Speed-up |
|---|---|---|---|
| 500 | 0.00985 | 0.000075 | 131x |
| 1000 | 0.04275 | 0.000170 | 251x |
| 2000 | 0.17413 | 0.000330 | 527x |
| 4000 | 0.76191 | 0.000716 | 1064x |

At 2000 tasks the function made ~4 million calls (naive) vs ~4 thousand (optimized).
The old version is kept as `find_duplicate_titles_naive` so a test proves both return identical results.
