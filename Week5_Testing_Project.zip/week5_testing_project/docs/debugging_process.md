# Debugging Process and Lessons Learned

## Method
1. Write tests for expected behaviour first (including edge cases).
2. Run the suite; save the raw output (`logs/error_log_before_fix.txt`).
3. For each failure read the traceback, reproduce, find the root cause, fix the smallest thing, re-run.
4. Keep the test as a regression test.

## Bugs found
| # | Test that failed | Error message | Root cause | Fix |
|---|---|---|---|---|
| 1 | `test_title_is_trimmed`, `test_whitespace_only_title_rejected`, `test_add_trims_title`, `test_add_rejects_blank_title`, `test_create_blank_title_returns_400` | `AssertionError` / `ValueError not raised` | `if not title` treats `"   "` as valid and never strips | `title.strip()` before checking |
| 1b | `test_non_string_rejected` | `TypeError: object of type 'int' has no len()` | No type check before `len()` | `isinstance(title, str)` |
| 2 | `test_due_today_does_not_crash` | `ZeroDivisionError: division by zero` | `importance*10/days` with days = 0 | `max(days, 0.5)` |
| 2b | `test_overdue_is_treated_as_most_urgent` | `-15.0 != 60` | negative days gave negative score | same `max()` fix |
| 2c | `test_invalid_importance_rejected` | `ValueError not raised` | importance never validated | range check 1-5 |
| 3 | `test_delete_missing_returns_false`, `test_delete_missing_task_returns_404` | `True is not false`, `204 != 404` | `dict.pop(id, None)` then `return True` regardless | `return pop(...) is not None`; API checks result |
| 4 | `filterTasks` case / whitespace tests | `deepEqual` mismatch | `includes(query)` is case-sensitive | lower-case + trim |
| 5 | `formatDueDays` tests | `'null days' !== 'No due date'` | no handling for null / 0 / negative | explicit branches |

## Debugging techniques used
- Reading tracebacks bottom-up to find the failing line.
- Reproducing with the smallest failing input (e.g. `priority_score(0, 3)`).
- Unit tests to isolate the layer (validator vs store vs API); the integration test then confirmed the layers agree.
- `cProfile` to locate the performance bottleneck (the nested loop with ~4M calls).

## Lessons learned
- Validate at the boundary (empty, whitespace, wrong type, zero, negative).
- A return value that is always `True` hides errors - functions should report what actually happened.
- Fixing a bug in a lower layer (store) also required updating the layer above (API -> 404).
- Measure before optimizing: profiling showed exactly where time was spent.
- Keeping the old slow implementation and testing both give the same output makes optimization safe.
