"""Profile the naive vs optimized duplicate finder.  Run from project root:
    python benchmarks/profile_duplicates.py
"""
import cProfile
import io
import pstats
import random
import string
import sys
import timeit
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from backend.store import TaskStore  # noqa: E402


def build_store(n):
    random.seed(42)
    store = TaskStore()
    words = ["".join(random.choices(string.ascii_lowercase, k=6)) for _ in range(n // 2)]
    for i in range(n):
        store.add(random.choice(words) + str(i % 7))
    return store


def profile(fn, label):
    pr = cProfile.Profile()
    pr.enable()
    fn()
    pr.disable()
    out = io.StringIO()
    pstats.Stats(pr, stream=out).sort_stats("cumulative").print_stats(4)
    print(f"--- cProfile: {label} ---")
    print(out.getvalue().strip().split("\n\n")[0])
    print()


if __name__ == "__main__":
    print(f"{'Tasks':>8} {'Naive O(n^2) (s)':>18} {'Optimized O(n) (s)':>20} {'Speed-up':>10}")
    for n in (500, 1000, 2000, 4000):
        s = build_store(n)
        assert s.find_duplicate_titles_naive() == s.find_duplicate_titles()
        t_naive = timeit.timeit(s.find_duplicate_titles_naive, number=3) / 3
        t_fast = timeit.timeit(s.find_duplicate_titles, number=3) / 3
        print(f"{n:>8} {t_naive:>18.5f} {t_fast:>20.6f} {t_naive / t_fast:>9.0f}x")
    print()
    s = build_store(2000)
    profile(s.find_duplicate_titles_naive, "naive, 2000 tasks")
    profile(s.find_duplicate_titles, "optimized, 2000 tasks")
