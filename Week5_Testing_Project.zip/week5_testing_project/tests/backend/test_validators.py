import unittest

from backend.validators import validate_title, priority_score


class TestValidateTitle(unittest.TestCase):
    def test_valid_title_is_returned(self):
        self.assertEqual(validate_title("Buy milk"), "Buy milk")

    def test_title_is_trimmed(self):
        self.assertEqual(validate_title("  Buy milk  "), "Buy milk")

    def test_empty_title_rejected(self):
        with self.assertRaises(ValueError):
            validate_title("")

    def test_whitespace_only_title_rejected(self):
        with self.assertRaises(ValueError):
            validate_title("     ")

    def test_none_rejected(self):
        with self.assertRaises(ValueError):
            validate_title(None)

    def test_non_string_rejected(self):
        with self.assertRaises(ValueError):
            validate_title(12345)

    def test_too_long_rejected(self):
        with self.assertRaises(ValueError):
            validate_title("x" * 101)

    def test_exactly_100_chars_allowed(self):
        self.assertEqual(len(validate_title("x" * 100)), 100)


class TestPriorityScore(unittest.TestCase):
    def test_normal_case(self):
        self.assertEqual(priority_score(5, 3), 6)

    def test_due_today_does_not_crash(self):
        self.assertEqual(priority_score(0, 3), 60)

    def test_overdue_is_treated_as_most_urgent(self):
        self.assertEqual(priority_score(-2, 3), 60)

    def test_invalid_importance_rejected(self):
        with self.assertRaises(ValueError):
            priority_score(3, 9)


if __name__ == "__main__":
    unittest.main()
