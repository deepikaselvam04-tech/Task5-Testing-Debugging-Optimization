"""Integration tests: HTTP layer + validators + store working together."""
import unittest

from backend.app import create_app


class TestTaskApi(unittest.TestCase):
    def setUp(self):
        self.client = create_app().test_client()

    def test_create_task_returns_201(self):
        r = self.client.post("/api/tasks", json={"title": "Buy milk"})
        self.assertEqual(r.status_code, 201)
        self.assertEqual(r.get_json()["title"], "Buy milk")

    def test_create_blank_title_returns_400(self):
        r = self.client.post("/api/tasks", json={"title": "   "})
        self.assertEqual(r.status_code, 400)
        self.assertIn("error", r.get_json())

    def test_create_with_invalid_json_returns_400(self):
        r = self.client.post("/api/tasks", data="not json",
                             content_type="application/json")
        self.assertEqual(r.status_code, 400)

    def test_get_missing_task_returns_404(self):
        self.assertEqual(self.client.get("/api/tasks/42").status_code, 404)

    def test_delete_missing_task_returns_404(self):
        self.assertEqual(self.client.delete("/api/tasks/42").status_code, 404)

    def test_full_lifecycle_create_list_delete(self):
        created = self.client.post("/api/tasks", json={"title": "Write report"}).get_json()
        self.assertEqual(len(self.client.get("/api/tasks").get_json()), 1)
        self.assertEqual(self.client.get(f"/api/tasks/{created['id']}").status_code, 200)
        self.assertEqual(self.client.delete(f"/api/tasks/{created['id']}").status_code, 204)
        self.assertEqual(self.client.get("/api/tasks").get_json(), [])

    def test_duplicates_endpoint(self):
        for title in ["Gym", "gym", "Study"]:
            self.client.post("/api/tasks", json={"title": title})
        self.assertEqual(self.client.get("/api/tasks/duplicates").get_json(), ["gym"])


if __name__ == "__main__":
    unittest.main()
