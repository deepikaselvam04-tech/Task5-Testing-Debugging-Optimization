import unittest

from backend.store import TaskStore


class TestTaskStore(unittest.TestCase):
    def setUp(self):
        self.store = TaskStore()

    def test_add_assigns_incrementing_ids(self):
        a = self.store.add("A")
        b = self.store.add("B")
        self.assertEqual((a["id"], b["id"]), (1, 2))

    def test_add_trims_title(self):
        self.assertEqual(self.store.add("  Study  ")["title"], "Study")

    def test_add_rejects_blank_title(self):
        with self.assertRaises(ValueError):
            self.store.add("   ")

    def test_get_missing_returns_none(self):
        self.assertIsNone(self.store.get(999))

    def test_delete_existing_returns_true(self):
        t = self.store.add("A")
        self.assertTrue(self.store.delete(t["id"]))
        self.assertIsNone(self.store.get(t["id"]))

    def test_delete_missing_returns_false(self):
        self.assertFalse(self.store.delete(999))

    def test_duplicates_case_insensitive(self):
        for t in ["Read", "read", "Write", "READ", "Code"]:
            self.store.add(t)
        self.assertEqual(self.store.find_duplicate_titles(), ["read"])

    def test_naive_and_optimized_duplicates_agree(self):
        for t in ["a", "A", "b", "c", "C", "c"]:
            self.store.add(t)
        self.assertEqual(self.store.find_duplicate_titles_naive(),
                         self.store.find_duplicate_titles())


if __name__ == "__main__":
    unittest.main()
