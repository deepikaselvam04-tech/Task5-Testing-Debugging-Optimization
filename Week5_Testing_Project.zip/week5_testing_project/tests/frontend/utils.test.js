const test = require("node:test");
const assert = require("node:assert/strict");
const { escapeHtml, filterTasks, formatDueDays, renderTaskList } = require("../../frontend/utils");

const tasks = [{ title: "Buy Milk" }, { title: "Write report" }, { title: "Gym" }];

test("escapeHtml escapes special characters", () => {
  assert.equal(escapeHtml('<b>"A&B"</b>'), "&lt;b&gt;&quot;A&amp;B&quot;&lt;/b&gt;");
});

test("filterTasks is case-insensitive", () => {
  assert.deepEqual(filterTasks(tasks, "milk"), [{ title: "Buy Milk" }]);
});

test("filterTasks ignores surrounding spaces", () => {
  assert.equal(filterTasks(tasks, "  gym ").length, 1);
});

test("filterTasks with empty query returns everything", () => {
  assert.equal(filterTasks(tasks, "").length, 3);
});

test("formatDueDays handles null", () => {
  assert.equal(formatDueDays(null), "No due date");
});

test("formatDueDays handles today, tomorrow, future and overdue", () => {
  assert.equal(formatDueDays(0), "Due today");
  assert.equal(formatDueDays(1), "Due tomorrow");
  assert.equal(formatDueDays(5), "Due in 5 days");
  assert.equal(formatDueDays(-2), "Overdue by 2 days");
});

test("renderTaskList escapes HTML (XSS protection)", () => {
  const html = renderTaskList([{ title: "<script>alert(1)</script>" }]);
  assert.ok(!html.includes("<script>"));
});

test("renderTaskList shows empty state", () => {
  assert.equal(renderTaskList([]), "<p>No tasks yet</p>");
});
