#!/usr/bin/env bash
# Runs the complete test suite (backend + frontend). Run from the project root.
set -e
echo "== Backend (pytest) =="
python -m pytest -v 2>/dev/null || python -m unittest discover -s tests/backend -t . -v
echo "== Frontend (node:test) =="
node --test tests/frontend/utils.test.js
