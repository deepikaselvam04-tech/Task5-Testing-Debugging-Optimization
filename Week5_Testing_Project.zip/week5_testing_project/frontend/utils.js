// Front-end helper functions for the Task Manager UI.

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function filterTasks(tasks, query) {
  const q = String(query || "").trim().toLowerCase();
  if (!q) return tasks;
  return tasks.filter((t) => t.title.toLowerCase().includes(q));
}

function formatDueDays(days) {
  if (days === null || days === undefined) return "No due date";
  if (days < 0) return `Overdue by ${-days} day${-days === 1 ? "" : "s"}`;
  if (days === 0) return "Due today";
  if (days === 1) return "Due tomorrow";
  return `Due in ${days} days`;
}

function renderTaskList(tasks) {
  if (!tasks.length) return "<p>No tasks yet</p>";
  return "<ul>" + tasks.map((t) => `<li>${escapeHtml(t.title)}</li>`).join("") + "</ul>";
}

module.exports = { escapeHtml, filterTasks, formatDueDays, renderTaskList };
