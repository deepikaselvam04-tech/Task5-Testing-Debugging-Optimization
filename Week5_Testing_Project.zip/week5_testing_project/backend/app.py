"""Flask REST API for the Task Manager."""
from flask import Flask, jsonify, request

from .store import TaskStore


def create_app(store=None):
    app = Flask(__name__)
    store = store or TaskStore()

    @app.post("/api/tasks")
    def create_task():
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            return jsonify(error="Body must be a JSON object"), 400
        try:
            task = store.add(data.get("title"), data.get("due_days"),
                             data.get("importance", 3))
        except ValueError as exc:
            return jsonify(error=str(exc)), 400
        return jsonify(task), 201

    @app.get("/api/tasks")
    def list_tasks():
        return jsonify(store.all())

    @app.get("/api/tasks/duplicates")
    def duplicates():
        return jsonify(store.find_duplicate_titles())

    @app.get("/api/tasks/<int:task_id>")
    def get_task(task_id):
        task = store.get(task_id)
        if task is None:
            return jsonify(error="Task not found"), 404
        return jsonify(task)

    @app.delete("/api/tasks/<int:task_id>")
    def delete_task(task_id):
        if not store.delete(task_id):
            return jsonify(error="Task not found"), 404
        return "", 204

    return app
