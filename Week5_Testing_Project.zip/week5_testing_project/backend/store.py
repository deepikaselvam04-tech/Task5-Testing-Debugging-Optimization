"""In-memory task storage."""
from collections import Counter

from .validators import validate_title


class TaskStore:
    def __init__(self):
        self._tasks = {}
        self._next_id = 1

    def add(self, title, due_days=None, importance=3):
        title = validate_title(title)
        task = {"id": self._next_id, "title": title,
                "due_days": due_days, "importance": importance}
        self._tasks[self._next_id] = task
        self._next_id += 1
        return task

    def get(self, task_id):
        return self._tasks.get(task_id)

    def delete(self, task_id):
        return self._tasks.pop(task_id, None) is not None

    def all(self):
        return list(self._tasks.values())

    # --- duplicate detection: two implementations (see benchmarks/) ---
    def find_duplicate_titles_naive(self):
        """O(n^2) version kept for benchmarking."""
        tasks = self.all()
        dups = []
        for i, a in enumerate(tasks):
            for b in tasks[i + 1:]:
                if a["title"].lower() == b["title"].lower():
                    if a["title"].lower() not in dups:
                        dups.append(a["title"].lower())
        return sorted(dups)

    def find_duplicate_titles(self):
        """O(n) version used by the API."""
        counts = Counter(t["title"].lower() for t in self._tasks.values())
        return sorted(title for title, n in counts.items() if n > 1)
