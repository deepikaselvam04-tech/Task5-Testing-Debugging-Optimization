"""Input validation and scoring helpers for the Task Manager backend."""


def validate_title(title):
    """Return the trimmed title or raise ValueError if it is invalid."""
    if not isinstance(title, str):
        raise ValueError("Title must be a string")
    title = title.strip()
    if not title:
        raise ValueError("Title is required")
    if len(title) > 100:
        raise ValueError("Title must be 100 characters or fewer")
    return title


def priority_score(days_until_due, importance):
    """Higher score = more urgent. importance is 1 (low) to 5 (high).

    Tasks due today or already overdue are treated as if due in half a day,
    which avoids division by zero and makes them the most urgent.
    """
    if not isinstance(importance, int) or not 1 <= importance <= 5:
        raise ValueError("Importance must be an integer between 1 and 5")
    return importance * 10 / max(days_until_due, 0.5)
